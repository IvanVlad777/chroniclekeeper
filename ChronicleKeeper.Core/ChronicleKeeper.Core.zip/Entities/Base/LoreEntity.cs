﻿using ChronicleKeeper.Core.Entities.HistoryTimelines;
using System.ComponentModel.DataAnnotations;

namespace ChronicleKeeper.Core.Entities.Base
{
    //public abstract class LoreEntity
    //{
    //    [Key]
    //    public int Id { get; set; }
    //    [Required]
    //    public string Name { get; set; } = string.Empty;
    //    public string Description { get; set; } = string.Empty;
    //    [Required]
    //    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    //    [Required]
    //    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    //    public virtual History? History { get; set; }

    //}
}
