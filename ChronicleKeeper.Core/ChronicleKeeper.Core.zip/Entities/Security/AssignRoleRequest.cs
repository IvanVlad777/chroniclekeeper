﻿namespace ChronicleKeeper.Core.Entities.Security
{
    public class AssignRoleRequest
    {
        public string UserId { get; set; }
        public string Role { get; set; }
    }
}
