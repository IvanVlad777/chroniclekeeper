﻿namespace ChronicleKeeper.Core.Entities.Geography.Ecosystems
{
    public class OceanEcosystem : WaterEcosystem
    {
        //public ICollection<SeaEcosystem> Seas { get; set; } = new List<SeaEcosystem>();
    }
}
