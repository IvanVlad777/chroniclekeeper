﻿using static ChronicleKeeper.Core.Enums.EcosystemEnums;

namespace ChronicleKeeper.Core.Entities.Geography.Ecosystems
{
    public class DesertEcosystem : Ecosystem
    {
        public DesertType Type { get; set; }
    }
}
