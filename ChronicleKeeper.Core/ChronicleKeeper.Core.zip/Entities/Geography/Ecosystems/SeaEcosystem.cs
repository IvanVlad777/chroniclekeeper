﻿using ChronicleKeeper.Core.Entities.Professions;
using System.ComponentModel.DataAnnotations.Schema;

namespace ChronicleKeeper.Core.Entities.Geography.Ecosystems
{
    public class SeaEcosystem : WaterEcosystem
    {
        //[ForeignKey("Ocean")]
        //public int? OceanId { get; set; }
        //public OceanEcosystem? Ocean { get; set; }
    }
}
