﻿namespace ChronicleKeeper.Core.Entities.Geography.Ecosystems
{
    public class SwampEcosystem : Ecosystem
    {
        public bool IsSaltwater { get; set; } // Freshwater vs. Saltwater swamp
    }
}
